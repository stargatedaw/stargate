/* finddefault.h -- find_default_device() declaration
   Roger Dannenberg, Jan 2021
*/

PmDeviceID find_default_device(char *path, int input, PmDeviceID id);
