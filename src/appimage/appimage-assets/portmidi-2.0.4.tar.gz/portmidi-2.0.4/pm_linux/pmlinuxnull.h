/* pmlinuxnull.h -- system-specific definitions */

PmError pm_linuxnull_init(void);
void pm_linuxnull_term(void);


